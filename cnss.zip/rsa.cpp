#include<bits/stdc++.h>
using namespace std;

int gcd(int a,int h){
	int temp;
	while(1){
		temp=a%h;
		if(temp==0){
			return h;
		}
		a=h;
		h=temp;
	}
}

int main(){
	double p=7;
	double q=11;
	double n=p*q;
	double e=2;
	double phi=(p-1)*(q-1);
	while(e<phi){
		if(gcd(e,phi)==1){
			break;
		}
		else{
			e++;
		}
	}
	double d1=1/e;
	double d=fmod(d1,phi);
	double msg=9;
	printf("message data: %lf\n",msg);
	double c=pow(msg,e);
	double m=pow(c,d);
	c=fmod(c,n);
	printf("encrypted data: %lf\n",c);
	
	m=fmod(m,n);
	printf("original data: %lf\n",m);
	return 0;
}
